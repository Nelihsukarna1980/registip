from kyt import *
import re

@bot.on(events.CallbackQuery(data=b'change'))
async def changee(event):
    async def changee_(event):
        async with bot.conversation(chat) as pw_conv:
            await event.edit("**Masukan IP VPS Lama:**\n(Ketik /cancel untuk membatalkan)")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if pw_msg.raw_text == "/cancel":
                await event.respond("Proses perubahan IP dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            old_ip = pw_msg.raw_text
            
        async with bot.conversation(chat) as user_conv:
            await event.respond("**Masukan IP VPS Baru:**\n(Ketik /cancel untuk membatalkan)")
            user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if user_msg.raw_text == "/cancel":
                await event.respond("Proses perubahan IP dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            new_ip = user_msg.raw_text

        # Ganti IP VPS di database
        if replace_vps_ip(sender.id, old_ip, new_ip):
            cmd = f'python3 /root/ganti-ip.py "{old_ip}" "{new_ip}"'
            try:
                result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            except subprocess.CalledProcessError:
                await event.respond("**Not Exist**")
            else:
                msg = f"""```{result}```
**» 🤖@RozTun**"""
                await event.respond(msg)
                await event.respond("Success", buttons=[[Button.inline("Menu", "menu")]])
        else:
            await event.respond("IP lama tidak ditemukan atau tidak dapat diganti.", buttons=[[Button.inline("Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await changee_(event)
    else:
        await changee_(event)

@bot.on(events.CallbackQuery(data=b'change_admin'))
async def chadmin(event):
    async def chadmin_(event):
        async with bot.conversation(chat) as pw_conv:
            await event.edit("**Masukan IP VPS Lama:**\n(Ketik /cancel untuk membatalkan)")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if pw_msg.raw_text == "/cancel":
                await event.respond("Proses perubahan IP dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            old_ip = pw_msg.raw_text
            
        async with bot.conversation(chat) as user_conv:
            await event.respond("**Masukan IP VPS Baru:**\n(Ketik /cancel untuk membatalkan)")
            user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if user_msg.raw_text == "/cancel":
                await event.respond("Proses perubahan IP dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            new_ip = user_msg.raw_text

        # Hanya eksekusi perintah penggantian IP di server
        cmd = f'python3 /root/ganti-ip.py "{old_ip}" "{new_ip}"'
        try:
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Tidak berhasil mengganti IP**")
        else:
            msg = f"""```{result}```
**» IP LAMA :** `{old_ip}`
**» IP BARU :** `{new_ip}`
**» 🤖@RozTun**"""
            await event.respond(msg)
            await event.respond("Success", buttons=[[Button.inline("Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await chadmin_(event)
    else:
        await chadmin_(event)