from kyt import *
import re

@bot.on(events.CallbackQuery(data=b'renew'))
async def renew(event):
    async def renew_(event):
        async with bot.conversation(chat) as pw_conv:
            await event.edit("**Input IP VPS:**\nKetik /cancel untuk membatalkan")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if pw_msg.raw_text == "/cancel":
                await event.respond("Proses perpanjangan dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            ip = pw_msg.raw_text
        
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30"), Button.inline(" 60 Day ", "60")]
            ])
            exp_cb = await exp_conv.wait_event(events.CallbackQuery)

            if exp_cb.data.decode("ascii") == "/cancel":
                await event.respond("Proses perpanjangan dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            exp = exp_cb.data.decode("ascii")

        # Jumlah hari tambahan berdasarkan expiry day
        additional_days = int(exp)

        # Tambahan: Potong saldo berdasarkan biaya perpanjangan
        harga = {"30": 10000, "60": 20000}.get(exp, 0)  # Tentukan harga perpanjangan
        saldo_user = check_saldo(sender.id)  # Periksa saldo pengguna

        if saldo_user < harga:
            await event.respond("Saldo Anda tidak mencukupi untuk memperpanjang IP. Silakan top up terlebih dahulu.", buttons=[[Button.inline("Menu", "menu")]])
            return

        update_saldo(sender.id, saldo_user - harga)  # Potong saldo pengguna

        # Perpanjang IP VPS di database
        if renew_vps_ip(sender.id, ip, additional_days):
            cmd = f'python3 /root/renew-ip.py "{ip}" "{exp}"'
            try:
                result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            except subprocess.CalledProcessError:
                await event.respond("**Not Exist**")
            else:
                msg = f"""```{result}```
**» 🤖@RozTun**"""
                await event.respond(msg)
                await event.respond("Back To Menu", buttons=[[Button.inline("Yes", "menu")]])
        else:
            await event.respond("IP tidak ditemukan atau tidak dapat diperpanjang.", buttons=[[Button.inline("Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renew_(event)
    else:
        await renew_(event)
        
@bot.on(events.CallbackQuery(data=b'renew_admin'))
async def renadmin(event):
    async def renadmin_(event):
        async with bot.conversation(chat) as pw_conv:
            await event.edit("**Input IP VPS:**\nKetik /cancel untuk membatalkan")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))

            if pw_msg.raw_text == "/cancel":
                await event.respond("Proses perpanjangan dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            ip = pw_msg.raw_text
        
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Expiry Day**", buttons=[
                [Button.inline(" 30 Day ", "30"),
                Button.inline(" 60 Day ", "60")]
                [Button.inline(" 90 Day ", "90"),
                Button.inline(" 360 Day ", "360")]
            ])
            exp_cb = await exp_conv.wait_event(events.CallbackQuery)

            if exp_cb.data.decode("ascii") == "/cancel":
                await event.respond("Proses perpanjangan dibatalkan.", buttons=[[Button.inline("Menu", "menu")]])
                return

            exp = exp_cb.data.decode("ascii")

        # Jumlah hari tambahan berdasarkan expiry day
        additional_days = int(exp)

        # Lanjutkan tanpa pengecekan atau operasi tambahan
        cmd = f'python3 /root/renew-ip.py "{ip}" "{exp}"'
        try:
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Not Exist**")
        else:
            msg = f"""```{result}```
**» 🤖@RozTun**"""
            await event.respond(msg)
            await event.respond("Back To Menu", buttons=[[Button.inline("Yes", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renadmin_(event)
    else:
        await renadmin_(event)