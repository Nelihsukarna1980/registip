from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	sender = await event.get_sender()
	sh = f' curl -sS https://raw.githubusercontent.com/RozTun/permission/main/admin | grep "###" | wc -l'
	usersc = subprocess.check_output(sh, shell=True).decode("ascii")
	val = valid(sender.id)
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	if val == "false":
		if sender.id in a:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
** PANEL USER**
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 Hallo __{sender.first_name}__ 🔰**
**🔰 User ID :** `{sender.id}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 User Bot :** `{get_user_count()}`
**🔰 User Autoscript:** `{usersc.strip()}`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
			await event.edit(msg, buttons=[
[Button.inline("ADD IP", "registrasi_admin"),
Button.inline("CHANGE IP", "change_admin")],
[Button.inline("PERPANJANG IP", "renew_admin"),
Button.inline(" LIST USER","list_users")],
[Button.inline(" ADD SALDO ","addsaldo")]])
		else:
			await event.answer("❌")
	else:
		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
** PANEL USER**
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 Hallo __{sender.first_name}__ 🔰**
**🔰 User ID :** `{sender.id}`
**🔰 Saldo :** Rp.`{val["saldo"]}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔰 1 IP/1 Bulan = 10K**
**🔰 1 IP/2 Bulan = 20K**
**━━━━━━━━━━━━━━━━━━━━━━━**
** NOTE :**
__Bebas Ganti IP Mau Sampai Berapa Kali Karna Tidak Akan Ada Pengurangan Saldo Jika Ganti IP Lewat Bot Kami!__
**━━━━━━━━━━━━━━━━━━━━━━━**
** Jika ada pertanyaan atau butuh bantuan, Silahkan hubungi @RozTun**
"""
		await event.edit(msg, buttons=[
[Button.inline("ADD IP", "registrasi"),
Button.inline("CHANGE IP", "change")],
[Button.inline("PERPANJANG IP", "renew"),
Button.inline(" CHECK IP","lihat_ip")],
[Button.inline(" 🔰 INFO AKUN 🔰 ","info")]])